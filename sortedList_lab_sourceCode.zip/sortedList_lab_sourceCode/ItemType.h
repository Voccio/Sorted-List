//skeleton of all code here came from C++ Data Structures 5th edition
#include<string>
using namespace std;

const int MAX_ITEMS = 10000;
enum RelationType{LESS, GREATER, EQUAL}; //enum declare

class ItemType
{
public:
	ItemType(); //default
	RelationType ComparedTo(ItemType) const; //enum const
	void Print() const; //print item to screen
	void Initialize(); //create item
	ItemType::ItemType(string string); //create item from user input
private:
	string astring; //item type arguement
};