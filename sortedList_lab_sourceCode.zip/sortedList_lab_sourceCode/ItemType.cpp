//skeleton of all code here came from C++ Data Structures 5th edition
#include "ItemType.h"
#include<iostream>
#include<time.h>
#include<stdlib.h>
using namespace std;

ItemType::ItemType() //default
{
}

RelationType ItemType::ComparedTo(ItemType otherItem) const //enum definition
{
	if(astring < otherItem.astring) //compare strings
		return LESS;
	else if(astring > otherItem.astring) //compare strings
		return GREATER;
	else return EQUAL; //if not last two, must be this
}

void ItemType::Initialize() //make item with 5 random characters
{
	astring.clear(); //clear string to make a clean item
	int ranchar; //declare variable
	for(int i = 0; i < 5; i++) //loop
	{
		ranchar = rand()%26; //call random function
		astring += ('a' +ranchar); //make string 5 random charaters long	
	}
	
}

ItemType::ItemType(string string) //make item from user input
{
	astring = string; //make private member = user input
}

void ItemType::Print() const //display item on screen
{
	cout << astring << endl; //item displayed 
}