/*
Joshua Murrill
7/22/12
GSP295
week2 lab
*/
#include"sortedListADT.h" //include directories
#include"Windows.h"
#include<iostream>
#include<string>
#include<conio.h>
using namespace std;

int main() //test driver
{
	int input; //declare variables needed
	double counter = 0;
	ItemType chars, nextChar, findChar;
	SortedType charList;
	bool found;
	char menu;
	string search;

	cout << "Enter a number of strings to create, staying under 10,000. " << endl; //prompt user for number of items in list
	cin >> input;
	charList.MakeItems(chars, input, counter); //make list that large
	cout << "All strings have been put into a sorted list. " << endl;
	cout << "It took " << counter << " long to create the list." << endl; //show how long it took

	do //menu loop options
	{                                                                              
		cout << "What would you like to do?" << endl;                                
		cout << "a. Get length of list." << endl;                              
		cout << "b. Make the list empty." << endl;                                  
		cout << "c. Search for an item on the list." << endl;                                          
		cout << "d. Put a item into the list." << endl;                                     
		cout << "e. Delete an item from the list." << endl;                                           
		cout << "f. Get the next item." << endl;
		cout << "g. Print the list of items." << endl;
		cout << "h. Quit." << endl;                                                  
		cin >> menu;                                                                      

		switch (menu)                                                                
		{             
		case 'a': //tell user size of list, works                                                                    
			cout << "Length of list is: " << endl;     
			cout << charList.GetLength() << endl;
			break;                                                                   
		case 'b': //make list empty and tell user size of list, works                                                                 
			cout << "List has been made empty. Size of list is now." << endl;
			charList.MakeEmpty();
			cout << charList.GetLength() << endl;                                                                                                    
			break;                                                                   
		case 'c': //search for item, works
			found = false;
			cout << "Enter an item to search for within the list." << endl;
			cin >> search;
			findChar = search;
			charList.GetItem(findChar, found, counter);
			cout << "Was the item in the list? " << endl;
			cout << "1 meaning item is found and 0 meaning item wasn't found." << endl;
			cout << found << endl;
			cout << "The time for this function to take place took:" << endl;
			cout << counter << endl;
			break;                                                                  
		case 'd': //add an item to the list, works                                                                   
			cout << "Put another item into the list, it'll be randomly generated, but sorted in order." << endl;                               
			charList.MakeItems(chars, 1, counter);
			cout << "The time for this function to take place took:" << endl;
			cout << counter << endl;
			break;                                                                  
		case 'e': //delete an item, works
			found = false;
			cout << "Enter an item to delete from the list." << endl;
			cin >> search;
			findChar = search;
			charList.DeleteItem(findChar, counter, found);
			cout << "Was item found and deleted." << endl;
			cout << "1 meaning item is found and 0 meaning item wasn't found." << endl;
			cout << found << endl;
			cout << "Size of list is now:" << endl;
			cout << charList.GetLength();
			cout << "The time for this function to take place took:" << endl;
			cout << counter << endl;
			break;                                                                 
		case 'f': //rest list and show next item, works                                                                
			cout << "Get the next item in the list." << endl;
			cout << "This is going to retrieve the first item in the list automatically." << endl;
			nextChar = charList.GetNextItem();
			nextChar.Print();
			break;
		case 'g': //print list, works
			cout << "The list contains: " << endl;
			charList.PrintList();
			cout << counter << endl;
			break;
		default:                                                                  
			continue;
		}
	}
	while (menu != 'h' ); //exit program, works                                                         
	cout << "Please press any key to exit ..." << endl;                           
	cin.sync();                                                                   
	_getch(); 
	return 0;
}