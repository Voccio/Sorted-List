//skeleton of all code here came from C++ Data Structures 5th edition
#include "sortedListADT.h"

SortedType::SortedType() //default
{
	length = 0; //initialize
	listData = NULL; //initialize
}

bool SortedType::IsFull() const //return true if list is full
{
	return (length == MAX_ITEMS);
	/*NodeType* location; //pointer for linked list
	try //exception handling
	{
		location = new NodeType; //make new
		delete location; //delete new
		return false; 
	}
	catch(std::bad_alloc exception) //if full catch error
	{
		return true; 
	}*/
}

int SortedType::GetLength() const //return length
{
	return length;
}

void SortedType::MakeEmpty() //make list empty
{
	NodeType* tempPtr; //create temp pointer 

	while(listData != NULL) //while items are in the list delete the item
	{
		tempPtr = listData; //temp point to hold current position
		listData = listData->next; //current position to goto next node
		delete tempPtr; //delete temp pointer
	}
	length = 0; //list is empty
}

ItemType SortedType::GetItem(ItemType item, bool& found, double& timetaken) //look for item, return item, tell user if it was found and how long it took
{
	double start, end; //variables for timer
	start = GetTickCount(); //start timer count

	bool moreToSearch;
	NodeType* location;

	location = listData;
	found = false;
	moreToSearch = (location != NULL);

	while (moreToSearch && !found)
	{
		switch(item.ComparedTo(location->info))
		{
		case GREATER:
			location = location ->next;
			moreToSearch = (location != NULL);
			break;
		case EQUAL:
			found = true;
			item = location->info;
			break;
		case LESS:
			moreToSearch = false;
			break;
		}
	}
	return item;
	end = GetTickCount(); //end time counter
	timetaken = (end-start); //compute number of cycles it took to complete function
}

void SortedType::PutItem(ItemType item, double& timetaken) //put an item into the list
{
	double start, end; //declare variables for time counter
	start = GetTickCount(); //start time counter

	NodeType* newNode; //pointer for linked list
	NodeType* predLoc = NULL; //pointer to node behind current position
	NodeType* location = listData; //pointer to current location
	bool moreToSearch = (location != NULL); //bool to keep searching

	while(moreToSearch) //loop
	{
		switch(item.ComparedTo(location->info)) //what to do if <>=
		{
		case GREATER: predLoc = location; //precedeing pointer becomes current position
			location = location->next; //current position becomes next node
			moreToSearch = (location != NULL); //are we still searching?
			break;
		case LESS: moreToSearch = false; //still searching
			break;
		}
	}

	newNode = new NodeType; //make new
	newNode->info = item; 

	if(predLoc == NULL) //if at beginning or end of list
	{
		newNode->next = listData; //point to current
		listData = newNode; //current point to the next node
	}
	else
	{
		newNode->next = location; //current position becomes next
		predLoc->next = newNode; //precedeing pointer becomes current position
	}
	length++; //list becomes bigger
	end = GetTickCount(); //end timer counter
	timetaken = (end-start); //calculate time counter
}

void SortedType::DeleteItem(ItemType item, double& timetaken, bool&found) //delete an item in the list
{
	double start, end; //declare variable for time counters
	start = GetTickCount(); //start time counter

	NodeType* location = listData;
	NodeType* tempLocation;
	bool moreToSearch = (location != NULL);

	

	while(moreToSearch && !found)
		switch(item.ComparedTo(location->info))
	{
		case GREATER:
			location = location->next;
			moreToSearch = (location != NULL);
			break;
		case EQUAL:
			found = true;
			item = location->info;
			tempLocation = location;
			location = location->next;
			delete tempLocation;
			break;
		case LESS:
			moreToSearch = false;
			break;
	}
	length--; //list becomes smaller
	end = GetTickCount(); //end time counter
	timetaken = (end-start); //calculate timer variable
}

void SortedType::ResetList() //reset
{
	currentPos = NULL; //make current position NULL
}

ItemType SortedType::GetNextItem() //get the item after the current position
{
	ItemType item; //item for return
	if(currentPos == NULL) //if NULL or not make current position next position
		currentPos = listData;
	item = currentPos->info; //make return item of what is in next node
	currentPos = currentPos->next; //position moves up one
	return item; //return
}

SortedType::~SortedType() //default deconstructor
{
	NodeType* tempPtr; //temp pointer for deletion operation

	while(listData != NULL) //loop
	{
		tempPtr = listData; //make temp current position
		listData = listData->next; //current position becomes next node
		delete tempPtr; //delete temp pointer that was current position
	}
}

void SortedType::PrintList() //display list on screen
{
	int length; //variable for length
	ItemType item; //item to access print function
	ResetList(); //start from beginning of list
	length = GetLength(); //set counter for iteration
	for (int counter = 1; counter <= length; counter++) //loop
	{
		item = GetNextItem(); //starting at NULL move to first item
		item.Print(); //display that item on screen
	}
}

void SortedType::MakeItems(ItemType& item, int num, double& timetaken) //create a list of user input of items
{
	double start, end; //variables for time counters
	start = GetTickCount(); //start timer counter
	for(int i = 0; i < num; i++) //loop
	{
		item.Initialize(); //access initialize function through item and make 1 item
		PutItem(item, timetaken); //put the just made item into a list of items
		item.Print(); //display the list as it is made
		
	}
	end = GetTickCount(); //end timer counter
	timetaken = (end-start); //calculate timer variable
}