//skeleton of all code here came from C++ Data Structures 5th edition
#include "ItemType.h"
#include"Windows.h"

struct NodeType;

class SortedType
{
public:
	SortedType(); //default
	SortedType(int max);
	~SortedType(); //deconstructor

	bool IsFull() const; //return true if full
	int GetLength() const; //return length of list
	void MakeEmpty(); //make list empty
	ItemType GetItem(ItemType item, bool& found, double& timetaken); //find and return item that user inputted
	void PutItem(ItemType item, double& timetaken); //put current item in the list
	void DeleteItem(ItemType item, double& timetaken, bool& found); //delete item that user inputted
	void ResetList(); //return position to beginning of list 
	ItemType GetNextItem(); //return item after the current position
	void PrintList(); //display list of items on screen
	void MakeItems(ItemType& item, int num, double& timetaken); //create list to size of user input
	

private:
	NodeType* listData; //pointer for linked list
	int length; //length of list counter
	NodeType* currentPos; //pointer for linked list
	ItemType info[MAX_ITEMS]; //class object of item type used as the storing input of this class
};

struct NodeType
{
	ItemType info; //Node Type for linked list
	NodeType* next; //pointer for linked list
};